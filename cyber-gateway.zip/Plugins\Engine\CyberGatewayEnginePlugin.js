var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Engine/CyberGatewayEnginePlugin.ts
var CyberGatewayEnginePlugin_exports = {};
__export(CyberGatewayEnginePlugin_exports, {
  CyberGatewayEnginePlugin: () => CyberGatewayEnginePlugin
});
module.exports = __toCommonJS(CyberGatewayEnginePlugin_exports);
var import_EnginePluginBase = require("@core/EnginePluginBase");
var PROMPT_INJECTION_PATTERNS = [
  /ignore\s+(all\s+)?(previous|prior)\s+instructions/i,
  /desatiende\s+(todas\s+las\s+)?instrucciones\s+(previas|anteriores)/i,
  /you\s+are\s+now\s+(DAN|unfiltered|jailbroken|root|developer\s+mode)/i,
  /ahora\s+eres\s+(un\s+modelo\s+sin\s+restricciones|modo\s+desarrollador|root)/i,
  /system\s*prompt\s*override/i,
  /reveal\s+(your\s+)?(system\s+instructions|internal\s+prompt|credentials)/i,
  /revela\s+(tus\s+)?(instrucciones\s+del\s+sistema|prompt\s+interno|contraseñas)/i,
  /\b(base64|rot13|hex)\s+decode\s+this\s+command\b/i,
  /exec\s*\(\s*["'`].*["'`]\s*\)/i,
  /<script[\s\S]*?>[\s\S]*?<\/script>/i,
  /union\s+select\s+.*\s+from/i,
  /;\s*(DROP|DELETE|ALTER)\s+TABLE/i,
  /\b(sudo|chmod\s+777|rm\s+-rf|\/etc\/shadow|\/etc\/passwd)\b/i
];
var MALICIOUS_URL_PATTERNS = [
  /https?:\/\/[^\s/$.?#].[^\s]*\.(xyz|top|work|click|loan|gq|cf|tk|buzz|rest|fit|link)\b/i,
  /https?:\/\/(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?::\d+)?/i,
  // Raw IPs in URLs
  /(bit\.ly|tinyurl\.com|t\.co|is\.gd|cutt\.ly|ow\.ly|buff\.ly)\/[a-zA-Z0-9_-]+/i,
  /https?:\/\/.*(login|verify|secure|update|banco|portal|auth).*\.(?!com|org|net|edu|io)[a-zA-Z0-9-]+\.[a-zA-Z]{2,}/i
  // Typosquatting
];
var CyberGatewayEnginePlugin = class extends import_EnginePluginBase.EnginePluginBase {
  // ── Hook: onSessionStart ──────────────────────────────────────────
  async onSessionStart(ctx) {
    const securityMode = ctx.getSecretWithOverride("SECURITY_MODE") || "block_threats";
    ctx.addBadge({
      id: "cyber-gateway-badge",
      label: `\u{1F6E1}\uFE0F CyberGateway: ${this.formatModeLabel(securityMode)}`,
      color: securityMode === "block_threats" || securityMode === "strict_zero_trust" ? "success" : "warning",
      icon: "ShieldCheck"
    });
    const currentStats = await ctx.store.getSession("stats") || {
      analyzed: 0,
      threatsBlocked: 0,
      threatsDetected: 0,
      startTime: Date.now()
    };
    await ctx.store.setSession("stats", currentStats);
  }
  // ── Hook: preMessageProcess (Inspección en Caliente) ──────────────
  async preMessageProcess(ctx, message) {
    const content = typeof message?.content === "string" ? message.content : JSON.stringify(message?.content || "");
    const sender = message?.from || message?.author || ctx.userId || "unknown_sender";
    const securityMode = ctx.getSecretWithOverride("SECURITY_MODE") || "block_threats";
    const detectInjection = ctx.getSecretWithOverride("DETECT_PROMPT_INJECTION") !== "false";
    const detectUrls = ctx.getSecretWithOverride("DETECT_MALICIOUS_URLS") !== "false";
    const detectBots = ctx.getSecretWithOverride("DETECT_AI_BOT_PATTERNS") !== "false";
    const blockedListRaw = ctx.getSecretWithOverride("BLOCKED_IDENTIFIERS") || "";
    const alertWebhook = ctx.getSecretWithOverride("ALERT_WEBHOOK_URL");
    await this.incrementStat(ctx, "analyzed");
    const blockedList = blockedListRaw.split("\n").map((s) => s.trim()).filter(Boolean);
    if (blockedList.some((id) => sender.includes(id) || content.includes(id))) {
      await this.logThreat(ctx, {
        type: "BLACKLISTED_SENDER",
        severity: "HIGH",
        sender,
        summary: `Remitente ${sender} coincide con identificador en lista negra.`,
        contentSnippet: content.slice(0, 120)
      });
      await this.notifySoc(alertWebhook, "BLACKLISTED_SENDER", sender, "Remitente bloqueado en lista negra");
      await this.incrementStat(ctx, "threatsBlocked");
      return {
        status: "intercepted",
        overrideResponse: "\u{1F6AB} [ACCESO DENEGADO]: Tu identificador ha sido bloqueado por las directivas de seguridad activas."
      };
    }
    if (detectInjection) {
      for (const pattern of PROMPT_INJECTION_PATTERNS) {
        if (pattern.test(content)) {
          await this.logThreat(ctx, {
            type: "PROMPT_INJECTION_ATTACK",
            severity: "CRITICAL",
            sender,
            matchedPattern: pattern.toString(),
            summary: "Intento de manipulaci\xF3n de instrucciones (Prompt Injection / Jailbreak) detectado.",
            contentSnippet: content.slice(0, 160)
          });
          await this.notifySoc(alertWebhook, "PROMPT_INJECTION_ATTACK", sender, `Patr\xF3n detectado: ${pattern}`);
          if (securityMode === "block_threats" || securityMode === "strict_zero_trust") {
            await this.incrementStat(ctx, "threatsBlocked");
            return {
              status: "intercepted",
              overrideResponse: "\u{1F6E1}\uFE0F [ALERTA DE SEGURIDAD]: Se detect\xF3 un intento de inyecci\xF3n de c\xF3digo o manipulaci\xF3n de prompt. La petici\xF3n fue neutralizada."
            };
          } else if (securityMode === "monitor_only") {
            await this.incrementStat(ctx, "threatsDetected");
            return {
              status: "continue",
              modifiedMessage: {
                ...message,
                content: `[\u26A0\uFE0F ALERTA DE SEGURIDAD: INTENTO DE INYECCI\xD3N DE PROMPT DETECTADO - PROCEDER CON CAUTELA]

${content}`
              }
            };
          }
        }
      }
    }
    if (detectUrls) {
      for (const urlPattern of MALICIOUS_URL_PATTERNS) {
        if (urlPattern.test(content)) {
          await this.logThreat(ctx, {
            type: "PHISHING_OR_MALICIOUS_LINK",
            severity: "HIGH",
            sender,
            matchedPattern: urlPattern.toString(),
            summary: "Enlace sospechoso, acortador o dominio de alto riesgo detectado en el mensaje.",
            contentSnippet: content.slice(0, 160)
          });
          await this.notifySoc(alertWebhook, "PHISHING_OR_MALICIOUS_LINK", sender, "Enlace malicioso detectado");
          if (securityMode === "block_threats" || securityMode === "strict_zero_trust") {
            await this.incrementStat(ctx, "threatsBlocked");
            return {
              status: "intercepted",
              overrideResponse: "\u{1F6AB} [ENLACE BLOQUEADO]: El mensaje contiene URLs o enlaces no autorizados que infringen las pol\xEDticas de seguridad."
            };
          }
        }
      }
    }
    if (detectBots) {
      const isHighEntropy = content.length > 500 && !content.includes(" ");
      const hasRepetitivePatterns = /(.)\1{30,}/.test(content);
      if (isHighEntropy || hasRepetitivePatterns) {
        await this.logThreat(ctx, {
          type: "AUTOMATED_BOT_FUZZING",
          severity: "MEDIUM",
          sender,
          summary: "Carga de datos an\xF3mala con patrones de bot / fuzzing automatizado.",
          contentSnippet: content.slice(0, 100)
        });
        if (securityMode === "strict_zero_trust") {
          await this.incrementStat(ctx, "threatsBlocked");
          return {
            status: "intercepted",
            overrideResponse: "\u26A0\uFE0F [PETICI\xD3N AN\xD3MALA]: Estructura de paquete no permitida por los filtros Zero Trust."
          };
        }
      }
    }
    return { status: "continue" };
  }
  // ── Hook: onLlmInput (Sanitización antes del Modelo) ──────────────
  async onLlmInput(ctx, llmPayload) {
    if (Array.isArray(llmPayload?.messages)) {
      llmPayload.messages = llmPayload.messages.map((m) => {
        if (typeof m.content === "string") {
          let sanitized = m.content.replace(/\b(?:\d{4}[ -]?){3}\d{4}\b/g, "[TARJETA_PROTEGIDA]");
          sanitized = sanitized.replace(/(sk-[a-zA-Z0-9]{32,}|ghp_[a-zA-Z0-9]{36})/g, "[API_KEY_REDACTED]");
          return { ...m, content: sanitized };
        }
        return m;
      });
    }
  }
  // ── Hook: onLlmOutput (Filtro de Salida / Prevención de Fugas) ────
  async onLlmOutput(ctx, rawOutput) {
    if (rawOutput?.choices?.[0]?.message?.content) {
      let content = rawOutput.choices[0].message.content;
      if (content.includes("FORWARD_AUTH_TOKEN") || content.includes("INCOMING_WEBHOOK_SECRET")) {
        content = content.replace(/FORWARD_AUTH_TOKEN[:=]\s*\S+/gi, "FORWARD_AUTH_TOKEN: [PROTECTED]");
        content = content.replace(/INCOMING_WEBHOOK_SECRET[:=]\s*\S+/gi, "INCOMING_WEBHOOK_SECRET: [PROTECTED]");
        rawOutput.choices[0].message.content = content;
        ctx.injectSystemMessage("[\u{1F6E1}\uFE0F AUDITOR\xCDA CYBERGATEWAY: Se bloque\xF3 una fuga accidental de secretos en la respuesta del modelo]");
      }
    }
    return rawOutput;
  }
  // ── Hook: onSessionEnd (Resumen de Métricas) ──────────────────────
  async onSessionEnd(ctx) {
    const stats = await ctx.store.getSession("stats");
    if (stats) {
      console.log(`[CyberGateway] Sesi\xF3n finalizada ${ctx.sessionId}:`);
      console.log(`  - Mensajes analizados: ${stats.analyzed}`);
      console.log(`  - Amenazas bloqueadas: ${stats.threatsBlocked}`);
    }
    ctx.removeBadge("cyber-gateway-badge");
  }
  // ── Métodos Auxiliares ────────────────────────────────────────────
  formatModeLabel(mode) {
    switch (mode) {
      case "block_threats":
        return "Bloqueo Activo";
      case "monitor_only":
        return "Modo Monitoreo";
      case "strict_zero_trust":
        return "Zero Trust";
      case "quarantine":
        return "Cuarentena";
      default:
        return mode;
    }
  }
  async incrementStat(ctx, key) {
    const stats = await ctx.store.getSession("stats") || { analyzed: 0, threatsBlocked: 0, threatsDetected: 0 };
    stats[key] = (stats[key] || 0) + 1;
    await ctx.store.setSession("stats", stats);
    const globalStats = await ctx.store.get("global_metrics") || { analyzed: 0, threatsBlocked: 0, threatsDetected: 0 };
    globalStats[key] = (globalStats[key] || 0) + 1;
    await ctx.store.set("global_metrics", globalStats);
  }
  async logThreat(ctx, threat) {
    const logEntry = {
      id: `thr_${Date.now()}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      sessionId: ctx.sessionId,
      ...threat
    };
    const history = await ctx.store.get("threat_history") || [];
    history.unshift(logEntry);
    if (history.length > 100)
      history.pop();
    await ctx.store.set("threat_history", history);
  }
  async notifySoc(webhookUrl, attackType, sender, details) {
    if (!webhookUrl || !webhookUrl.startsWith("http"))
      return;
    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: "Urano-CyberGateway",
          alertType: attackType,
          sender,
          details,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          priority: "CRITICAL"
        })
      });
    } catch (err) {
      console.error(`[CyberGateway] Error enviando alerta al SOC: ${err.message}`);
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CyberGatewayEnginePlugin
});
