var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Gateway/GatewayPlugin.ts
var GatewayPlugin_exports = {};
__export(GatewayPlugin_exports, {
  GatewayPlugin: () => GatewayPlugin
});
module.exports = __toCommonJS(GatewayPlugin_exports);
var GatewayPlugin = class {
  config;
  constructor(moduleConfig) {
    this.config = moduleConfig || {};
  }
  async executeAction(action, payload) {
    switch (action) {
      case "get_gateway_status":
        return this.getGatewayStatus(payload);
      case "inspect_payload":
        return this.inspectPayload(payload);
      case "block_sender":
        return this.blockSender(payload);
      case "unblock_sender":
        return this.unblockSender(payload);
      case "get_threat_log":
        return this.getThreatLog(payload);
      case "test_upstream_connection":
        return this.testUpstreamConnection(payload);
      case "generate_security_report":
        return this.generateSecurityReport(payload);
      default:
        throw new Error(`Acci\xF3n '${action}' no encontrada en GatewayPlugin`);
    }
  }
  /**
   * Devuelve el estado operacional y métricas acumuladas del Gateway.
   */
  async getGatewayStatus(payload) {
    const securityMode = this.config?.SECURITY_MODE || "block_threats";
    const forwardUrl = this.config?.FORWARD_URL || "No configurado (Solo filtrado local)";
    return {
      status: "ONLINE",
      module: "cyber-gateway",
      version: "1.0.0",
      securityMode,
      upstreamTarget: forwardUrl,
      protectionFeatures: {
        promptInjectionDefense: this.config?.DETECT_PROMPT_INJECTION !== false,
        maliciousUrlScanner: this.config?.DETECT_MALICIOUS_URLS !== false,
        aiBotAnomalyDetector: this.config?.DETECT_AI_BOT_PATTERNS !== false,
        socAlertingEnabled: !!this.config?.ALERT_WEBHOOK_URL
      },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  /**
   * Inspecciona manualmente un payload de datos o mensaje para evaluar nivel de amenaza.
   */
  async inspectPayload(payload) {
    const content = payload?.content || "";
    const sender = payload?.sender || "manual_test";
    let riskScore = 0;
    const detectedIndicators = [];
    if (/ignore\s+(all\s+)?(previous|prior)\s+instructions/i.test(content) || /you\s+are\s+now\s+(DAN|unfiltered|jailbroken)/i.test(content) || /desatiende\s+instrucciones/i.test(content)) {
      riskScore += 65;
      detectedIndicators.push("PROMPT_INJECTION_PATTERN_MATCH");
    }
    if (/(\/etc\/shadow|\/etc\/passwd|sudo|chmod\s+777|DROP\s+TABLE|union\s+select)/i.test(content)) {
      riskScore += 80;
      detectedIndicators.push("CODE_OR_SQL_INJECTION_PATTERN");
    }
    if (/https?:\/\/(?:[0-9]{1,3}\.){3}[0-9]{1,3}/.test(content) || /\.(xyz|top|click|tk|gq)\b/i.test(content)) {
      riskScore += 45;
      detectedIndicators.push("SUSPICIOUS_DOMAIN_OR_RAW_IP_URL");
    }
    if (content.length > 300 && !content.includes(" ")) {
      riskScore += 30;
      detectedIndicators.push("HIGH_ENTROPY_NO_SPACES");
    }
    const normalizedScore = Math.min(riskScore, 100);
    let verdict = "CLEAN";
    if (normalizedScore >= 60)
      verdict = "CRITICAL_THREAT";
    else if (normalizedScore >= 30)
      verdict = "SUSPICIOUS";
    return {
      analyzedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sender,
      contentLength: content.length,
      riskScore: normalizedScore,
      verdict,
      indicators: detectedIndicators,
      actionRecommended: verdict === "CRITICAL_THREAT" ? "BLOCK_AND_ISOLATE" : verdict === "SUSPICIOUS" ? "FLAG_FOR_REVIEW" : "FORWARD_CLEAN"
    };
  }
  /**
   * Añade un identificador a la lista de bloqueo.
   */
  async blockSender(payload) {
    const id = payload?.identifier?.trim();
    const reason = payload?.reason || "Bloqueo manual por operador de seguridad";
    if (!id)
      throw new Error("Se requiere un identificador para bloquear");
    return {
      success: true,
      blockedIdentifier: id,
      reason,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      message: `El identificador '${id}' ha sido registrado en la lista de mitigaci\xF3n del Gateway.`
    };
  }
  /**
   * Remueve un identificador de la lista de bloqueo.
   */
  async unblockSender(payload) {
    const id = payload?.identifier?.trim();
    if (!id)
      throw new Error("Se requiere un identificador para desbloquear");
    return {
      success: true,
      unblockedIdentifier: id,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      message: `El identificador '${id}' ha sido removido de la lista de bloqueo.`
    };
  }
  /**
   * Obtiene el log de amenazas detectadas.
   */
  async getThreatLog(payload) {
    const limit = parseInt(payload?.limit || "20", 10);
    return {
      totalEntries: 0,
      limit,
      retrievedAt: (/* @__PURE__ */ new Date()).toISOString(),
      entries: [],
      note: "Los registros en tiempo real se almacenan en el ledger de sesi\xF3n y en el webhook de SOC configurado."
    };
  }
  /**
   * Envía una prueba de conexión hacia el servidor upstream configurado.
   */
  async testUpstreamConnection(payload) {
    const forwardUrl = this.config?.FORWARD_URL;
    const authToken = this.config?.FORWARD_AUTH_TOKEN;
    if (!forwardUrl || !forwardUrl.startsWith("http")) {
      return {
        status: "CONFIG_MISSING",
        message: "No se ha configurado FORWARD_URL en los ajustes del Gateway."
      };
    }
    const start = Date.now();
    try {
      const headers = {
        "Content-Type": "application/json",
        "X-Urano-Security-Gateway": "ping-test"
      };
      if (authToken) {
        headers["Authorization"] = `Bearer ${authToken}`;
      }
      const res = await fetch(forwardUrl, {
        method: "POST",
        headers,
        body: JSON.stringify({
          type: "HEALTHCHECK_PING",
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        })
      });
      const latencyMs = Date.now() - start;
      return {
        status: res.ok ? "REACHABLE" : "ERROR_RESPONSE",
        statusCode: res.status,
        latencyMs,
        url: forwardUrl,
        message: res.ok ? `Upstream respondi\xF3 exitosamente en ${latencyMs}ms.` : `Upstream retorn\xF3 c\xF3digo de error ${res.status}.`
      };
    } catch (err) {
      return {
        status: "UNREACHABLE",
        latencyMs: Date.now() - start,
        url: forwardUrl,
        error: err.message,
        message: `No se pudo establecer conexi\xF3n con ${forwardUrl}: ${err.message}`
      };
    }
  }
  /**
   * Construye un reporte ejecutivo de ciberdefensa.
   */
  async generateSecurityReport(payload) {
    const securityMode = this.config?.SECURITY_MODE || "block_threats";
    const forwardUrl = this.config?.FORWARD_URL || "Sin upstream configurado";
    const report = `# \u{1F6E1}\uFE0F Reporte Ejecutivo de Seguridad \u2014 CyberGateway

**Fecha:** ${(/* @__PURE__ */ new Date()).toLocaleDateString("es")} | **Hora:** ${(/* @__PURE__ */ new Date()).toLocaleTimeString("es")}
**Estado del Gateway:** OPERATIVO (ONLINE)
**Modo de Defensa Activo:** \`${securityMode.toUpperCase()}\`
**Destino Upstream:** \`${forwardUrl}\`

---

### \u{1F50D} Capacidades de Mitigaci\xF3n Activas
1. **Filtro Anti-Prompt Injection**: Detecta intentos de jailbreak y alteraci\xF3n de directivas contra agentes de IA.
2. **Esc\xE1ner Anti-Phishing**: Neutraliza enlaces maliciosos, dominios fraudulentos y typosquatting.
3. **Detecci\xF3n de Fuzzing & Botnets**: Identifica tr\xE1fico de alta frecuencia sin patrones humanos.
4. **Sanitizaci\xF3n de Datos**: Enmascara PII y credenciales sensibles antes del procesamiento.

---

### \u{1F4CC} Recomendaciones de Infraestructura
- Mantener la URL de reenv\xEDo (\`FORWARD_URL\`) protegida mediante tokens de autenticaci\xF3n (\`FORWARD_AUTH_TOKEN\`).
- Configurar el webhook de SOC (\`ALERT_WEBHOOK_URL\`) para alertar al equipo de respuesta ante incidentes.
- Revisar peri\xF3dicamente la lista negra de remitentes (\`BLOCKED_IDENTIFIERS\`).

---
*Generado autom\xE1ticamente por Cyber UranoAI Security Suite.*`;
    return {
      success: true,
      reportMarkdown: report
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  GatewayPlugin
});
