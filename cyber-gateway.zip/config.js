var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// config.ts
var config_exports = {};
__export(config_exports, {
  CyberGatewayConfig: () => CyberGatewayConfig
});
module.exports = __toCommonJS(config_exports);
var CyberGatewayConfig = {
  name: "cyber-gateway",
  description: "AI Security Gateway & Reverse Proxy para Canales y Servicios. Inspecciona en tiempo real phishing, inyecciones de prompt, ataques coordinados por IA y reenv\xEDa tr\xE1fico limpio a la infraestructura interna.",
  icon: "ShieldAlert",
  category: "Ciberseguridad",
  inDesktop: true,
  inCloud: true,
  cloudOnly: false,
  // ──────────────────────────────────────────
  // CAPA CHANNEL PLUGIN (Webhooks dinámicos)
  // ──────────────────────────────────────────
  channelPlugin: true,
  waitForAgent: true,
  skipOutboundReply: true,
  syncTimeoutMs: 3e4,
  experimentalWebSocket: true,
  // Explicit opt-in for this experimental plugin only.
  webhookMaxConcurrent: 2,
  webhookQueueTimeoutMs: 6e4,
  webhookExecutionTimeoutMs: 18e4,
  // ──────────────────────────────────────────
  // CAPA ENGINE PLUGIN (Middleware de Sesión e Inspección en caliente)
  // ──────────────────────────────────────────
  enginePlugin: true,
  engineHooks: [
    "onSessionStart",
    "preMessageProcess",
    "postMessageProcess",
    "onLlmInput",
    "onLlmOutput",
    "onSessionEnd"
  ],
  enginePluginPath: "Plugins/Engine/CyberGatewayEnginePlugin",
  enabledPlugins: ["Gateway"],
  // ──────────────────────────────────────────
  // AJUSTES EN EL VAULT (Configuración de Seguridad)
  // ──────────────────────────────────────────
  settings: [
    { name: "REQUIRE_WEBHOOK_AUTH", type: "checkbox", title: "Exigir secreto para recibir webhooks", description: "Act\xEDvalo fuera del laboratorio local. Sin secreto configurado, rechaza peticiones.", default: false },
    {
      name: "SECURITY_MODE",
      type: "select",
      title: "Modo de Seguridad del Gateway",
      description: "Define c\xF3mo reacciona el Gateway al detectar una anomal\xEDa o ataque.",
      options: [
        { label: "\u{1F6E1}\uFE0F Bloqueo Activo (Recomendado) \u2014 Neutraliza amenazas y notifica al SOC", value: "block_threats" },
        { label: "\u{1F441}\uFE0F Solo Monitoreo \u2014 Registra amenazas y reenv\xEDa con etiqueta [SUSPICIOUS]", value: "monitor_only" },
        { label: "\u{1F512} Zero Trust Estricto \u2014 Bloquea todo contenido con score de riesgo > 30%", value: "strict_zero_trust" },
        { label: "\u{1F4E6} Cuarentena \u2014 Retiene el mensaje para revisi\xF3n humana previa", value: "quarantine" }
      ],
      default: "block_threats",
      perAgent: true
    },
    {
      name: "FORWARD_URL",
      type: "text",
      title: "URL de Reenv\xEDo Interno (Upstream Backend)",
      description: "URL de los servidores internos donde se reenv\xEDa el tr\xE1fico limpio validado.",
      placeholder: "https://servicios.empresa.local/api/v1/webhook",
      perAgent: true
    },
    {
      name: "FORWARD_AUTH_TOKEN",
      type: "password",
      title: "Token de Autenticaci\xF3n para Upstream",
      description: "Token Bearer o clave compartida enviada en Authorization header al servidor interno."
    },
    {
      name: "INCOMING_WEBHOOK_SECRET",
      type: "password",
      title: "Secreto de Verificaci\xF3n Webhook Entrante",
      description: "Firma HMAC / Token secreto esperado en cabeceras x-hub-signature o x-gateway-secret."
    },
    {
      name: "DETECT_PROMPT_INJECTION",
      type: "checkbox",
      title: "Detectar Inyecciones de Prompt y Jailbreaks de IA",
      description: "Analiza patrones de manipulaci\xF3n contra agentes y modelos de lenguaje.",
      default: true,
      perAgent: true
    },
    {
      name: "DETECT_MALICIOUS_URLS",
      type: "checkbox",
      title: "Escanear Enlaces Sospechosos / Phishing",
      description: "Extrae y eval\xFAa la reputaci\xF3n de URLs y dominios en los mensajes recibidos.",
      default: true,
      perAgent: true
    },
    {
      name: "DETECT_AI_BOT_PATTERNS",
      type: "checkbox",
      title: "Detecci\xF3n de Ataques Automatizados por IA / Botnets",
      description: "Reconoce patrones de alta frecuencia, ausencia de errores humanos y fuzzing sem\xE1ntico.",
      default: true,
      perAgent: true
    },
    {
      name: "ALERT_WEBHOOK_URL",
      type: "text",
      title: "Webhook de Notificaci\xF3n de Alertas SOC",
      description: "Endpoint donde se env\xEDan alertas de intrusi\xF3n en tiempo real (Slack, Teams, SIEM, Discord, Telegram SOC).",
      placeholder: "https://soc.empresa.com/api/alerts"
    },
    {
      name: "BLOCKED_IDENTIFIERS",
      type: "textarea",
      title: "Lista Negra de Remitentes / IPs Bloqueados",
      description: "N\xFAmeros de tel\xE9fono, UserIDs o IPs bloqueados permanentemente (uno por l\xEDnea).",
      placeholder: "+1234567890\nuser_bad_actor\n198.51.100.4",
      perAgent: true
    },
    {
      name: "TARGET_AGENT",
      type: "channel_agent_select",
      title: "Agente Vinculado / Enrutador",
      description: "Vac\xEDo o Enrutador: Hybrid Router (triggers, sesi\xF3n, default). Un agente concreto: todo el webhook va a ese agente."
    },
    {
      name: "allowedAgents",
      type: "dynamic",
      title: "Agentes Disponibles para Redirecci\xF3n",
      label: "Mapeo de Agentes Autorizados",
      description: "Agentes a los que el router puede hacer handoff. Vac\xEDo = sin restricci\xF3n.",
      fields: [
        {
          name: "agentId",
          key: "agentId",
          label: "Agente",
          type: "channel_agent_select",
          includeRouter: false,
          required: true
        }
      ]
    }
  ],
  // ──────────────────────────────────────────
  // ESQUEMAS DE HERRAMIENTAS MCP EXPUESTAS
  // ──────────────────────────────────────────
  pluginSchemas: {
    Gateway: {
      actions: {
        get_gateway_status: {
          label: "Obtener estado y m\xE9tricas del Gateway de Seguridad",
          description: "Muestra total de mensajes analizados, amenazas bloqueadas, tasa de mitigaci\xF3n y estado de upstream.",
          fields: []
        },
        inspect_payload: {
          label: "Inspeccionar manualmente un mensaje o payload",
          description: "Ejecuta el motor de an\xE1lisis profundo heur\xEDstico + sem\xE1ntico sobre un texto o paquete de datos.",
          fields: [
            { name: "content", type: "required", label: "Texto o JSON a inspeccionar" },
            { name: "sender", type: "text", label: "Identificador del remitente (opcional)" }
          ]
        },
        block_sender: {
          label: "Bloquear remitente o IP maliciosa",
          description: "A\xF1ade un ID de usuario, tel\xE9fono o direcci\xF3n IP a la lista de mitigaci\xF3n activa del Gateway.",
          fields: [
            { name: "identifier", type: "required", label: "ID de usuario, IP o n\xFAmero de tel\xE9fono" },
            { name: "reason", type: "required", label: "Motivo del bloqueo / Tipo de ataque" }
          ]
        },
        unblock_sender: {
          label: "Desbloquear remitente o IP",
          description: "Remueve un identificador de la lista de bloqueo del Gateway.",
          fields: [
            { name: "identifier", type: "required", label: "ID o IP a desbloquear" }
          ]
        },
        get_threat_log: {
          label: "Consultar registro de amenazas detectadas",
          description: "Devuelve las \xFAltimas alertas e intentos de ataque neutralizados por el Gateway.",
          fields: [
            { name: "limit", type: "text", label: "L\xEDmite de registros (default 20)" }
          ]
        },
        test_upstream_connection: {
          label: "Probar conectividad con el servidor interno de destino",
          description: "Env\xEDa un ping autenticado a la URL de reenv\xEDo para validar que el upstream est\xE9 operativo.",
          fields: []
        },
        generate_security_report: {
          label: "Generar reporte ejecutivo de seguridad del Gateway",
          description: "Construye un resumen estructurado para el equipo directivo y el SOC.",
          fields: []
        }
      }
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CyberGatewayConfig
});
