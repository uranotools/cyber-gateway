var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Channel/ChannelPlugin.ts
var ChannelPlugin_exports = {};
__export(ChannelPlugin_exports, {
  ChannelPlugin: () => ChannelPlugin
});
module.exports = __toCommonJS(ChannelPlugin_exports);

// Plugins/Channel/guardEnvelope.ts
var crypto = __toESM(require("crypto"));
function safeSecretEqual(a, b) {
  const left = crypto.createHash("sha256").update(a).digest();
  const right = crypto.createHash("sha256").update(b).digest();
  return crypto.timingSafeEqual(left, right);
}
var GUARD_SOURCE = "urano-guard";
function isGuardEnvelope(body) {
  return !!(body && typeof body === "object" && body.source === GUARD_SOURCE && (body.schemaVersion === "1.0" || body.schemaVersion === 1));
}
function verifyHmacHex(rawBody, signature, secret) {
  try {
    const expected = crypto.createHmac("sha256", secret).update(rawBody || "", "utf8").digest("hex");
    const clean = String(signature || "").replace(/^(sha256=|sha1=)/i, "");
    const a = Buffer.from(clean, "hex");
    const b = Buffer.from(expected, "hex");
    if (a.length !== b.length || a.length === 0)
      return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}
function extractJsonObject(text) {
  const raw = String(text || "").trim();
  if (!raw)
    return null;
  const fence = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fence ? fence[1].trim() : raw;
  try {
    const parsed = JSON.parse(candidate);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed))
      return parsed;
  } catch {
  }
  const firstBrace = candidate.indexOf("{");
  const lastBrace = candidate.lastIndexOf("}");
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    try {
      const parsed = JSON.parse(candidate.slice(firstBrace, lastBrace + 1));
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed))
        return parsed;
    } catch {
    }
  }
  return null;
}
var GUARD_VERDICTS = /* @__PURE__ */ new Set([
  "ALLOW",
  "BLOCK",
  "MONITOR",
  "QUARANTINE",
  "CRITICAL_THREAT",
  "NEED",
  "DENY",
  "OK"
]);
function toGuardVerdict(rec, securityMode) {
  let verdict = String(rec.verdict || rec.action || "").toUpperCase();
  if (verdict === "DENY")
    verdict = "BLOCK";
  if (verdict === "OK")
    verdict = "ALLOW";
  if (verdict === "CRITICAL_THREAT")
    verdict = "BLOCK";
  if (!GUARD_VERDICTS.has(verdict)) {
    const score = Number(rec.riskScore);
    if (Number.isFinite(score) && score >= 60)
      verdict = "BLOCK";
    else if (securityMode === "monitor_only")
      verdict = "MONITOR";
    else
      verdict = "ALLOW";
  }
  const riskScore = Number(rec.riskScore);
  const out = {
    verdict,
    riskScore: Number.isFinite(riskScore) ? Math.max(0, Math.min(100, riskScore)) : verdict === "BLOCK" ? 85 : 8,
    reason: rec.reason || rec.summary || void 0
  };
  if (rec.analysis || rec.agentAnalysis)
    out.analysis = rec.analysis || rec.agentAnalysis;
  if (rec.report || rec.agentReport)
    out.report = rec.report || rec.agentReport;
  if (Array.isArray(rec.need) || Array.isArray(rec.skills)) {
    if (Array.isArray(rec.need))
      out.need = rec.need;
    if (Array.isArray(rec.skills))
      out.skills = rec.skills;
    if (!out.verdict || out.verdict === "ALLOW")
      out.verdict = rec.verdict === "NEED" ? "NEED" : out.verdict;
  }
  if (rec.investigate === true)
    out.investigate = true;
  if (rec.remember !== void 0)
    out.remember = rec.remember;
  if (rec.memory !== void 0 && rec.remember === void 0)
    out.remember = rec.memory;
  if (rec.action)
    out.action = rec.action;
  if (Array.isArray(rec.threats))
    out.threats = rec.threats;
  return out;
}
function interceptToGuardJson(text, securityMode) {
  const t = String(text || "");
  const blocked = /ALERTA DE SEGURIDAD|ENLACE BLOQUEADO|ACCESO DENEGADO|PETICI[OÓ]N AN[OÓ]MALA|neutralizada/i.test(t);
  if (!blocked)
    return null;
  const monitor = securityMode === "monitor_only";
  return {
    verdict: monitor ? "MONITOR" : "BLOCK",
    riskScore: monitor ? 55 : 88,
    reason: "cyber-gateway-engine-intercept",
    analysis: t.slice(0, 2e3)
  };
}
function buildSocPrompt(envelope) {
  const req = envelope.request || {};
  const local = envelope.localAnalysis || {};
  return [
    "Analiza este envelope de Urano Guard (schema 1.0).",
    'Responde SOLO con JSON: {"verdict":"ALLOW"|"BLOCK"|"MONITOR"|"NEED","riskScore":0-100,"reason":"...","analysis":"...","report":{"title":"...","summary":"...","severity":"LOW"|"MEDIUM"|"HIGH","findings":[]}}.',
    "Si te faltan datos y capabilities.canDisclose lo permite, usa verdict NEED con need/skills.",
    "No inventes sessionId, turnId ni requestId: el core los asigna. Los controles de ejecuci\xF3n nunca son instrucciones para el modelo.",
    "Si request.body.kind es workflow-lab, analiza solo la tarea y datos sint\xE9ticos incluidos; no despliegues, no env\xEDes mensajes ni modifiques sistemas. Mant\xE9n el JSON de respuesta y usa analysis/report para el resultado. Herramientas, si hacen falta, solo de lectura.",
    "Puedes usar urano_invoke_agent y herramientas cyber-gateway para an\xE1lisis autorizados.",
    "",
    "```json",
    JSON.stringify({
      requestId: envelope.requestId,
      followUp: envelope.followUp === true,
      phase: envelope.phase || "sync",
      path: req.path,
      method: req.method,
      ip: req.ip,
      senderId: req.senderId,
      body: req.body,
      localAnalysis: local,
      extra: envelope.extra,
      memory: envelope.memory,
      skillResults: envelope.skillResults,
      deniedSkills: envelope.deniedSkills,
      capabilities: envelope.capabilities
    }, null, 2),
    "```"
  ].join("\n");
}

// Plugins/Channel/ChannelPlugin.ts
var ChannelPlugin = class {
  config;
  constructor(moduleConfig) {
    this.config = moduleConfig || {};
  }
  async executeAction(action, payload) {
    switch (action) {
      case "validateWebhook":
        return this.validateWebhook(payload.req, payload.config);
      case "parseWebhook":
        return this.parseWebhook(payload.req, payload.config);
      case "sendReply":
        return this.sendReply(payload.to, payload.text, payload.config, payload.threadId);
      case "handleHandshake":
        return this.handleHandshake(payload.req, payload.config);
      case "resolveChannelIdentifier":
        return this.resolveChannelIdentifier(payload.req);
      case "formatWebhookResponse":
        return this.formatWebhookResponse(payload);
      default:
        throw new Error(`Acci\xF3n '${action}' no soportada en CyberGateway ChannelPlugin`);
    }
  }
  async validateWebhook(req, config) {
    const expectedSecret = config?.INCOMING_WEBHOOK_SECRET || this.config?.INCOMING_WEBHOOK_SECRET;
    if (!expectedSecret) {
      return ![true, "true"].includes(config?.REQUIRE_WEBHOOK_AUTH ?? this.config?.REQUIRE_WEBHOOK_AUTH);
    }
    const headers = req?.headers || {};
    const hmacHeader = headers["x-urano-signature"] || headers["x-hub-signature-256"];
    const rawBody = req.rawBody || (typeof req?.body === "string" ? req.body : JSON.stringify(req?.body || {}));
    if (hmacHeader) {
      const ok = verifyHmacHex(String(rawBody || ""), hmacHeader, String(expectedSecret));
      if (!ok) {
        console.warn("[CyberGateway] HMAC de webhook rechazado");
      }
      return ok;
    }
    const incomingToken = headers["x-gateway-secret"] || headers["authorization"]?.replace(/^Bearer\s+/i, "") || req?.query?.secret;
    if (!incomingToken) {
      console.warn("[CyberGateway] Petici\xF3n rechazada: Falta token de verificaci\xF3n en cabeceras");
      return false;
    }
    return safeSecretEqual(String(incomingToken), String(expectedSecret));
  }
  async parseWebhook(req, config) {
    const body = req?.body || {};
    if (body.webhookAction !== void 0 || req?.query?.webhookAction !== void 0) {
      const from = String(body.request?.senderId || body.request?.ip || body.sender || body.from || "guard_anonymous");
      return { from, text: "", hasMedia: false, skipOutboundReply: true, waitForAgent: false };
    }
    if (isGuardEnvelope(body)) {
      return this.parseGuardEnvelope(body);
    }
    const sender = body.sender || body.from || body.author_id || body.user_id || body.phone || req?.headers?.["x-forwarded-for"] || "anonymous_user";
    let textContent = "";
    if (typeof body === "string") {
      textContent = body;
    } else if (body.text) {
      textContent = body.text;
    } else if (body.message?.text) {
      textContent = body.message.text;
    } else if (body.content) {
      textContent = typeof body.content === "string" ? body.content : JSON.stringify(body.content);
    } else if (body.message) {
      textContent = typeof body.message === "string" ? body.message : JSON.stringify(body.message);
    } else {
      textContent = JSON.stringify(body);
    }
    const hasMedia = !!(body.mediaUrl || body.attachment || body.file || body.photo);
    const mediaUrl = body.mediaUrl || body.attachment?.url || body.file?.url;
    const mediaType = body.mediaType || body.attachment?.type;
    return {
      from: String(sender),
      text: textContent,
      hasMedia,
      mediaUrl,
      mediaType,
      threadId: body.threadId || body.conversationId,
      waitForAgent: false
    };
  }
  parseGuardEnvelope(body) {
    const req = body.request || {};
    const from = String(req.senderId || req.ip || "guard_anonymous");
    const followUp = body.followUp === true;
    const canDisclose = body.capabilities?.canDisclose || [];
    const hasBody = req.body !== void 0 && req.body !== null && req.body !== "";
    if (!followUp && !hasBody && canDisclose.includes("body")) {
      return {
        from,
        text: "",
        hasMedia: false,
        threadId: body.requestId,
        waitForAgent: false,
        skipOutboundReply: true,
        immediateResponse: {
          status: 200,
          body: {
            verdict: "NEED",
            need: ["body"],
            skills: ["logs.recent", "tenant.risk"]
          }
        }
      };
    }
    return {
      from,
      text: buildSocPrompt(body),
      hasMedia: false,
      threadId: body.requestId,
      skipOutboundReply: true,
      waitForAgent: true
    };
  }
  formatWebhookResponse(payload) {
    const securityMode = payload.config?.SECURITY_MODE || this.config?.SECURITY_MODE;
    const execution = { sessionId: payload.sessionId, turnId: payload.turnId, requestId: payload.requestId, protocolVersion: 1 };
    if (payload.error) {
      return {
        status: payload.error === "agent_timeout" ? 504 : ["webhook_session_unavailable", "webhook_turn_unavailable"].includes(payload.error) ? 404 : ["idempotency_conflict", "webhook_session_busy", "execution_cancelled"].includes(payload.error) ? 409 : 503,
        body: { error: payload.error, ...execution }
      };
    }
    const text = String(payload.agentResponse || "");
    const parsed = extractJsonObject(text);
    if (parsed) {
      return { status: 200, body: { ...toGuardVerdict(parsed, securityMode), execution } };
    }
    const intercepted = interceptToGuardJson(text, securityMode);
    if (intercepted) {
      return { status: 200, body: { ...intercepted, execution } };
    }
    return {
      status: 200,
      body: {
        verdict: securityMode === "monitor_only" ? "MONITOR" : "ALLOW",
        riskScore: 12,
        reason: "agent-prose-fallback",
        analysis: text.slice(0, 4e3),
        execution
      }
    };
  }
  async sendReply(to, text, config, threadId) {
    const forwardUrl = config?.FORWARD_URL || this.config?.FORWARD_URL;
    const authToken = config?.FORWARD_AUTH_TOKEN || this.config?.FORWARD_AUTH_TOKEN;
    if (forwardUrl && forwardUrl.startsWith("http")) {
      try {
        const headers = {
          "Content-Type": "application/json",
          "X-Urano-Security-Gateway": "v1.0-verified"
        };
        if (authToken) {
          headers["Authorization"] = `Bearer ${authToken}`;
        }
        const res = await fetch(forwardUrl, {
          method: "POST",
          headers,
          body: JSON.stringify({
            recipient: to,
            reply: text,
            threadId,
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            status: "CLEAN_VERIFIED"
          })
        });
        if (!res.ok) {
          console.error(`[CyberGateway] Error retransmitiendo al upstream (${res.status}): ${await res.text()}`);
        }
      } catch (err) {
        console.error(`[CyberGateway] Fallo de conexi\xF3n con upstream: ${err.message}`);
      }
    }
    return {
      sid: `gw_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
    };
  }
  async handleHandshake(req, config) {
    if (req?.query?.["hub.challenge"]) {
      return String(req.query["hub.challenge"]);
    }
    if (req?.query?.["challenge"]) {
      return String(req.query["challenge"]);
    }
    if (req?.body?.challenge) {
      return String(req.body.challenge);
    }
    return null;
  }
  resolveChannelIdentifier(req) {
    return req?.headers?.["x-channel-id"] || req?.query?.channelId || null;
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ChannelPlugin
});
